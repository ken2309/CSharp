﻿namespace Demo_Forms
{
    partial class Ex07
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnLuu = new System.Windows.Forms.Button();
            this.btnSua = new System.Windows.Forms.Button();
            this.btnThem = new System.Windows.Forms.Button();
            this.txtDonGia = new System.Windows.Forms.TextBox();
            this.txtTenTS = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtMaTS = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pbHinh = new System.Windows.Forms.PictureBox();
            this.lvDSTraSua = new System.Windows.Forms.ListView();
            this.colMaTra = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colTenTra = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colDonGia = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.imgListTraSuaLarge = new System.Windows.Forms.ImageList(this.components);
            this.imgListTraSuaSmall = new System.Windows.Forms.ImageList(this.components);
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radTile = new System.Windows.Forms.RadioButton();
            this.radList = new System.Windows.Forms.RadioButton();
            this.radDetails = new System.Windows.Forms.RadioButton();
            this.radSmallIcon = new System.Windows.Forms.RadioButton();
            this.radLargeIcon = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.ofdFile = new System.Windows.Forms.OpenFileDialog();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbHinh)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnXoa);
            this.groupBox2.Controls.Add(this.btnLuu);
            this.groupBox2.Controls.Add(this.btnSua);
            this.groupBox2.Controls.Add(this.btnThem);
            this.groupBox2.Controls.Add(this.txtDonGia);
            this.groupBox2.Controls.Add(this.txtTenTS);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.txtMaTS);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.pbHinh);
            this.groupBox2.Location = new System.Drawing.Point(513, 54);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox2.Size = new System.Drawing.Size(264, 420);
            this.groupBox2.TabIndex = 7;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Chi tiết Trà sữa";
            // 
            // btnXoa
            // 
            this.btnXoa.Location = new System.Drawing.Point(136, 315);
            this.btnXoa.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(112, 35);
            this.btnXoa.TabIndex = 3;
            this.btnXoa.Text = "Xoá";
            this.btnXoa.UseVisualStyleBackColor = true;
            this.btnXoa.Click += new System.EventHandler(this.btnXoa_Click);
            // 
            // btnLuu
            // 
            this.btnLuu.Location = new System.Drawing.Point(136, 360);
            this.btnLuu.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnLuu.Name = "btnLuu";
            this.btnLuu.Size = new System.Drawing.Size(112, 35);
            this.btnLuu.TabIndex = 3;
            this.btnLuu.Text = "Lưu";
            this.btnLuu.UseVisualStyleBackColor = true;
            this.btnLuu.Click += new System.EventHandler(this.btnLuu_Click);
            // 
            // btnSua
            // 
            this.btnSua.Location = new System.Drawing.Point(15, 360);
            this.btnSua.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnSua.Name = "btnSua";
            this.btnSua.Size = new System.Drawing.Size(112, 35);
            this.btnSua.TabIndex = 3;
            this.btnSua.Text = "Sửa";
            this.btnSua.UseVisualStyleBackColor = true;
            this.btnSua.Click += new System.EventHandler(this.btnSua_Click);
            // 
            // btnThem
            // 
            this.btnThem.Location = new System.Drawing.Point(15, 315);
            this.btnThem.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(112, 35);
            this.btnThem.TabIndex = 3;
            this.btnThem.Text = "Thêm";
            this.btnThem.UseVisualStyleBackColor = true;
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click);
            // 
            // txtDonGia
            // 
            this.txtDonGia.Location = new System.Drawing.Point(84, 258);
            this.txtDonGia.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtDonGia.Name = "txtDonGia";
            this.txtDonGia.Size = new System.Drawing.Size(169, 26);
            this.txtDonGia.TabIndex = 2;
            // 
            // txtTenTS
            // 
            this.txtTenTS.Location = new System.Drawing.Point(84, 218);
            this.txtTenTS.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtTenTS.Name = "txtTenTS";
            this.txtTenTS.Size = new System.Drawing.Size(169, 26);
            this.txtTenTS.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(9, 263);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 20);
            this.label4.TabIndex = 1;
            this.label4.Text = "Đơn giá";
            // 
            // txtMaTS
            // 
            this.txtMaTS.Location = new System.Drawing.Point(84, 178);
            this.txtMaTS.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtMaTS.Name = "txtMaTS";
            this.txtMaTS.Size = new System.Drawing.Size(169, 26);
            this.txtMaTS.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(10, 223);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 20);
            this.label3.TabIndex = 1;
            this.label3.Text = "Tên TS";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 183);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Mã TS";
            // 
            // pbHinh
            // 
            this.pbHinh.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbHinh.Location = new System.Drawing.Point(54, 29);
            this.pbHinh.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pbHinh.Name = "pbHinh";
            this.pbHinh.Size = new System.Drawing.Size(149, 128);
            this.pbHinh.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbHinh.TabIndex = 0;
            this.pbHinh.TabStop = false;
            this.pbHinh.Click += new System.EventHandler(this.pbHinh_Click);
            // 
            // lvDSTraSua
            // 
            this.lvDSTraSua.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colMaTra,
            this.colTenTra,
            this.colDonGia});
            this.lvDSTraSua.FullRowSelect = true;
            this.lvDSTraSua.GridLines = true;
            this.lvDSTraSua.HideSelection = false;
            this.lvDSTraSua.LargeImageList = this.imgListTraSuaLarge;
            this.lvDSTraSua.Location = new System.Drawing.Point(13, 136);
            this.lvDSTraSua.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.lvDSTraSua.Name = "lvDSTraSua";
            this.lvDSTraSua.Size = new System.Drawing.Size(488, 338);
            this.lvDSTraSua.SmallImageList = this.imgListTraSuaSmall;
            this.lvDSTraSua.TabIndex = 6;
            this.lvDSTraSua.UseCompatibleStateImageBehavior = false;
            this.lvDSTraSua.SelectedIndexChanged += new System.EventHandler(this.lvDSTraSua_SelectedIndexChanged);
            // 
            // colMaTra
            // 
            this.colMaTra.Text = "Mã Trà";
            // 
            // colTenTra
            // 
            this.colTenTra.Text = "Tên Trà";
            // 
            // colDonGia
            // 
            this.colDonGia.Text = "Đơn Giá";
            // 
            // imgListTraSuaLarge
            // 
            this.imgListTraSuaLarge.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imgListTraSuaLarge.ImageSize = new System.Drawing.Size(50, 50);
            this.imgListTraSuaLarge.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // imgListTraSuaSmall
            // 
            this.imgListTraSuaSmall.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imgListTraSuaSmall.ImageSize = new System.Drawing.Size(16, 16);
            this.imgListTraSuaSmall.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radTile);
            this.groupBox1.Controls.Add(this.radList);
            this.groupBox1.Controls.Add(this.radDetails);
            this.groupBox1.Controls.Add(this.radSmallIcon);
            this.groupBox1.Controls.Add(this.radLargeIcon);
            this.groupBox1.Location = new System.Drawing.Point(13, 54);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Size = new System.Drawing.Size(490, 72);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "View Style";
            // 
            // radTile
            // 
            this.radTile.AutoSize = true;
            this.radTile.Location = new System.Drawing.Point(417, 29);
            this.radTile.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radTile.Name = "radTile";
            this.radTile.Size = new System.Drawing.Size(58, 24);
            this.radTile.TabIndex = 0;
            this.radTile.Text = "Tile";
            this.radTile.UseVisualStyleBackColor = true;
            this.radTile.CheckedChanged += new System.EventHandler(this.radOption_CheckedChanged);
            // 
            // radList
            // 
            this.radList.AutoSize = true;
            this.radList.Location = new System.Drawing.Point(346, 29);
            this.radList.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radList.Name = "radList";
            this.radList.Size = new System.Drawing.Size(59, 24);
            this.radList.TabIndex = 0;
            this.radList.Text = "List";
            this.radList.UseVisualStyleBackColor = true;
            this.radList.CheckedChanged += new System.EventHandler(this.radOption_CheckedChanged);
            // 
            // radDetails
            // 
            this.radDetails.AutoSize = true;
            this.radDetails.Location = new System.Drawing.Point(252, 29);
            this.radDetails.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radDetails.Name = "radDetails";
            this.radDetails.Size = new System.Drawing.Size(83, 24);
            this.radDetails.TabIndex = 0;
            this.radDetails.Text = "Details";
            this.radDetails.UseVisualStyleBackColor = true;
            this.radDetails.CheckedChanged += new System.EventHandler(this.radOption_CheckedChanged);
            // 
            // radSmallIcon
            // 
            this.radSmallIcon.AutoSize = true;
            this.radSmallIcon.Location = new System.Drawing.Point(132, 29);
            this.radSmallIcon.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radSmallIcon.Name = "radSmallIcon";
            this.radSmallIcon.Size = new System.Drawing.Size(108, 24);
            this.radSmallIcon.TabIndex = 0;
            this.radSmallIcon.Text = "Small Icon";
            this.radSmallIcon.UseVisualStyleBackColor = true;
            this.radSmallIcon.CheckedChanged += new System.EventHandler(this.radOption_CheckedChanged);
            // 
            // radLargeIcon
            // 
            this.radLargeIcon.AutoSize = true;
            this.radLargeIcon.Checked = true;
            this.radLargeIcon.Location = new System.Drawing.Point(9, 29);
            this.radLargeIcon.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.radLargeIcon.Name = "radLargeIcon";
            this.radLargeIcon.Size = new System.Drawing.Size(110, 24);
            this.radLargeIcon.TabIndex = 0;
            this.radLargeIcon.TabStop = true;
            this.radLargeIcon.Text = "Large Icon";
            this.radLargeIcon.UseVisualStyleBackColor = true;
            this.radLargeIcon.CheckedChanged += new System.EventHandler(this.radOption_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.BlueViolet;
            this.label1.Location = new System.Drawing.Point(205, 13);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(283, 37);
            this.label1.TabIndex = 4;
            this.label1.Text = "DANH SÁCH TRÀ SỮA";
            // 
            // ofdFile
            // 
            this.ofdFile.FileName = "openFileDialog1";
            // 
            // Ex07
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(786, 484);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.lvDSTraSua);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "Ex07";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Danh sách Trà sữa";
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbHinh)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnLuu;
        private System.Windows.Forms.Button btnSua;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.TextBox txtDonGia;
        private System.Windows.Forms.TextBox txtTenTS;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtMaTS;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pbHinh;
        private System.Windows.Forms.ListView lvDSTraSua;
        private System.Windows.Forms.ColumnHeader colMaTra;
        private System.Windows.Forms.ColumnHeader colTenTra;
        private System.Windows.Forms.ColumnHeader colDonGia;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radTile;
        private System.Windows.Forms.RadioButton radList;
        private System.Windows.Forms.RadioButton radDetails;
        private System.Windows.Forms.RadioButton radSmallIcon;
        private System.Windows.Forms.RadioButton radLargeIcon;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ImageList imgListTraSuaLarge;
        private System.Windows.Forms.ImageList imgListTraSuaSmall;
        private System.Windows.Forms.OpenFileDialog ofdFile;
    }
}