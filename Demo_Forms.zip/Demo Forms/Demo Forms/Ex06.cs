﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Demo_Forms
{
    public partial class Ex06 : Form
    {
        // Biến toàn cục -> sử dụng chung
        static string strChuoiKetNoi = @"Data Source=QUANGKHAI-MILAP\SQLEXPRESS;Initial Catalog=QLSV;Integrated Security=True";

        // bước 1. Khởi tạo đối tượng kết nối
        SqlConnection connect = new SqlConnection(strChuoiKetNoi);

        public Ex06()
        {
            InitializeComponent();
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            // Lấy dữ liệu từ giao diện lưu vào các biến để lưu trữ - xử lý - truy xuất
            string mssv = txtMSSV.Text;
            string hoTen = txtHoTen.Text;
            string ngaySinh = dtpNgaySinh.Value.ToString("yyyy-MM-dd");
            int gioiTinh = radNam.Checked ? 1 : 0; // Nam ~ 1 và Nữ ~ 0
            decimal diemTB = nudDiem.Value;

            // bước 2. Mở kết nối
            connect.Open();

            // bước 3. Xây dựng câu truy vấn
            string strFormat = "INSERT INTO SINH_VIEN(MSSV, HoTen, NgaySinh, GioiTinh, DiemTB) VALUES ('{0}', '{1}', '{2}', '{3}', '{4}')";
            string sql = string.Format(strFormat, mssv, hoTen, ngaySinh, gioiTinh, diemTB);

            // bước 4. Xây dựng đối tượng lệnh thực thi (SqlCommand)
            SqlCommand cmd = new SqlCommand(sql, connect);

            // bước 5. thực thi lệnh
            int count = cmd.ExecuteNonQuery();

            // bước 6. Hiển thị kết quả
            if(count > 0)
            {
                MessageBox.Show("Thêm thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Thêm thất bại!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            // bước 7. Đóng kết nối
            connect.Close();
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            // Lấy dữ liệu
            string mssv = txtMSSV.Text;

            // Mở kết nối đến CSDL
            connect.Open();

            // Xây dựng câu truy vấn
            string strFormat = "DELETE FROM SINH_VIEN WHERE MSSV = {0}";
            string sql = string.Format(strFormat, mssv);

            // Khởi tạo đối tượng thực thi
            SqlCommand cmd = new SqlCommand(sql, connect);

            // Thực thi câu lệnh
            int count = cmd.ExecuteNonQuery();

            // Kiểm tra -> trả kết quả hiển thị
            if(count > 0)
            {
                MessageBox.Show("Xoá thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Xoá thất bại!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            // Đóng kết nối
            connect.Close();
        }

        private void btnCapNhat_Click(object sender, EventArgs e)
        {
            // Lấy dữ liệu
            string mssv = txtMSSV.Text;
            string hoTen = txtHoTen.Text;
            string ngaySinh = dtpNgaySinh.Value.ToString("yyyy-MM-dd");
            int gioiTinh = radNam.Checked ? 1 : 0; // Nam ~ 1 và Nữ ~ 0
            decimal diemTB = nudDiem.Value;

            // Mở kết nối đến CSDL
            connect.Open();

            // Xây dựng câu truy vấn
            string strFormat = "UPDATE SINH_VIEN SET HoTen = '{0}', NgaySinh = '{1}', GioiTinh = '{2}', DiemTB = '{3}' WHERE MSSV = '{4}'";
            string sql = string.Format(strFormat, hoTen, ngaySinh, gioiTinh, diemTB, mssv);

            // Khởi tạo đối tượng thực thi
            SqlCommand cmd = new SqlCommand(sql, connect);

            // Thực thi câu lệnh
            int count = cmd.ExecuteNonQuery();

            // Kiểm tra -> trả kết quả hiển thị
            if (count > 0)
            {
                MessageBox.Show("Cập nhật thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Cập nhật thất bại!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            // Đóng kết nối
            connect.Close();
        }

        private void btnSoLuong_Click(object sender, EventArgs e)
        {
            // Mở kết nối đến CSDL
            connect.Open();

            // Xây dựng câu truy vấn
            string sql = "SELECT COUNT(*) FROM SINH_VIEN";

            // Khởi tạo đối tượng thực thi
            SqlCommand cmd = new SqlCommand(sql, connect);

            // Thực thi câu lệnh
            int count = Convert.ToInt32(cmd.ExecuteScalar());

            MessageBox.Show(string.Format("Có {0} sinh viên", count), "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);

            // Đóng kết nối
            connect.Close();
        }
    }
}
