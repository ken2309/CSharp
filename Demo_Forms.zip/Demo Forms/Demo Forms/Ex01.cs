﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Demo_Forms
{
    public partial class Ex01 : Form
    {
        public Ex01()
        {
            InitializeComponent();
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            if (cbbPhongBan.SelectedIndex >= 0 && !string.IsNullOrEmpty(txtHoTenNV.Text))
            {
                string hoTenNV = txtHoTenNV.Text;

                if ((string)cbbPhongBan.SelectedItem == "Nghiên cứu")
                {
                    if (lstPNC.Items.Contains(hoTenNV))
                    {
                        lstPNC.SelectedItem = hoTenNV;
                    }
                    else
                    {
                        lstPNC.Items.Add(hoTenNV);
                    }
                }
                else
                {
                    if (lstPQL.Items.Contains(hoTenNV))
                    {
                        lstPQL.SelectedItem = hoTenNV;
                    }
                    else
                    {
                        lstPQL.Items.Add(hoTenNV);
                    }
                }

                txtHoTenNV.Text = string.Empty;
                cbbPhongBan.SelectedItem = "Nghiên cứu";
            }
            else
            {
                MessageBox.Show("Vui lòng nhập dữ liệu!");
            }
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void lstPNC_Leave(object sender, EventArgs e)
        {
            //lstPNC.ClearSelected();
        }

        private void btnPhai_Click(object sender, EventArgs e)
        {
            // PNC > PQL
            if(lstPNC.SelectedIndex >= 0) // đã chọn nhân viên PNC
            {
                lstPQL.Items.Add(lstPNC.SelectedItem);
                lstPNC.Items.Remove(lstPNC.SelectedItem);
                // lstPNC.Items.RemoveAt(lstPNC.SelectedIndex);
            }
            else
            {
                MessageBox.Show("Bạn chưa chọn nhân viên phòng nghiên cứu!");
            }
        }
        private void btnTrai_Click(object sender, EventArgs e)
        {
            // <
            if (lstPQL.SelectedIndex >= 0)
            {
                lstPNC.Items.Add(lstPQL.SelectedItem);
                lstPQL.Items.Remove(lstPQL.SelectedItem);
            }
            else
            {
                MessageBox.Show("Bạn chưa chọn nhân viên phòng quản lý!");
            }
        }

        private void lstPNC_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstPNC.SelectedIndex > 0)
            {
                cbbPhongBan.SelectedItem = "Nghiên cứu";
                txtHoTenNV.Text = lstPNC.SelectedItem.ToString();
            }
        }

        private void lstPQL_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstPQL.SelectedIndex > 0)
            {
                cbbPhongBan.SelectedItem = "Quản lý";
                txtHoTenNV.Text = lstPQL.SelectedItem.ToString();
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            lstPNC.ClearSelected();
            lstPQL.ClearSelected();
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            if(lstPNC.SelectedIndex >= 0)
            {
                lstPNC.Items.RemoveAt(lstPNC.SelectedIndex);
            }

            if (lstPQL.SelectedIndex >= 0)
            {
                lstPQL.Items.RemoveAt(lstPQL.SelectedIndex);
            }
        }
    }
}
