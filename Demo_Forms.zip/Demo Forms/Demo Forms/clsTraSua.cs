﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Forms
{
    public class clsTraSua
    {
        private string _maTra;

        public string MaTra
        {
            get { return _maTra; }
            set { _maTra = value; }
        }
        private string _tenTra;

        public string TenTra
        {
            get { return _tenTra; }
            set { _tenTra = value; }
        }
        private long _donGia;

        public long DonGia
        {
            get { return _donGia; }
            set { _donGia = value; }
        }
    }
}
