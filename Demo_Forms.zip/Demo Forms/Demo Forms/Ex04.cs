﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Demo_Forms
{
    public partial class Ex04 : Form
    {
        public Ex04()
        {
            InitializeComponent();
        }
               
        private void txtSo1_TextChanged(object sender, EventArgs e)
        {
            Tinh();
        }

        private void txtSo2_TextChanged(object sender, EventArgs e)
        {
            Tinh();
        }

        private void Tinh()
        {
            // Kiểm tra dữ liệu nhập
            if (string.IsNullOrEmpty(txtSo1.Text) || string.IsNullOrEmpty(txtSo2.Text))
            {
                //MessageBox.Show("Vui lòng nhập đầy đủ thông tin!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Lấy giá trị -> chuyển dữ liệu về kiểu số thực
            float so1 = float.Parse(txtSo1.Text);
            float so2 = float.Parse(txtSo2.Text);

            lblTong.Text = (so1 + so2).ToString();
            lblHieu.Text = (so1 - so2).ToString();
            lblTich.Text = (so1 * so2).ToString();

            // Kiểm tra mẫu số khác không trong phép chia
            if (so2 != 0)
            {
                lblThuong.Text = (so1 / so2).ToString();
            }
            else
            {
                lblThuong.Text = "Không chia được cho 0";
            }
        }

        
    }
}
