﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Demo_Forms
{
    public partial class Ex05 : Form
    {
        public Ex05()
        {
            InitializeComponent();
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnMoi_Click(object sender, EventArgs e)
        {
            Ex01 frm = new Ex01();
            frm.MdiParent = this;
            frm.Show();

            //txtA.Text = string.Empty;
            //txtB.Text = string.Empty;
            //txtC.Text = string.Empty;

            //txtKetQua.Text = string.Empty;
        }

        private void btnGiai_Click(object sender, EventArgs e)
        {
            if(string.IsNullOrEmpty(txtA.Text) || string.IsNullOrEmpty(txtB.Text) || string.IsNullOrEmpty(txtC.Text))
            {
                MessageBox.Show("Vui lòng nhập dữ liệu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            float a = float.Parse(txtA.Text);
            float b = float.Parse(txtB.Text);
            float c = float.Parse(txtC.Text);

            GiaiPT2(a, b, c);
        }

        private void GiaiPT2(float a, float b, float c)
        {
            string ketQua = string.Empty;

            // Nếu a == 0
            // -> Giai PT bậc 1
                // Nếu b == 0 && c == 0 -> PT vô số nghiệm
                // Nếu b == 0 && c != 0 -> PT vô nghiệm
                // Nếu b != 0 -> PT có 1 nghiệm x = -b/a
            // Nếu a != 0
            // -> Tính delta
            // delta < 0 -> PT vô nghiệm
            // delta == 0 -> PT có nghiệm kép x = -b/2a
            // delta > 0 -> PT có 2 nghiệm phân biệt
                // x1 = (-b - sqrt(delta)) / 2a
                // x2 = (-b + sqrt(delta)) / 2a

            if(a == 0)
            {
                // Giải PT bậc I: bx + c = 0
                if (b == 0 && c == 0) ketQua = "PT vô số nghiệm";
                if (b == 0 && c != 0) ketQua = "PT vô nghiệm";
                if (b != 0) ketQua = "PT có 1 nghiệm x = " + (-b / a);
            }
            else
            {
                // Giải PT bậc 2: ax2 + bx + c = 0
                float delta = b * b - 4 * a * c;
                double x1, x2;

                if (delta < 0) ketQua = "PT vô nghiệm";
                if (delta == 0) ketQua = "PT có nghiệm kép x1 = x2 = " + (-b / (2 * a));
                if(delta > 0)
                {
                    x1 = (-b - Math.Sqrt(delta)) / (2 * a);
                    x2 = (-b + Math.Sqrt(delta)) / (2 * a);

                    ketQua = string.Format("Phương trình có hai nghiệm phân biệt:{0}x1 = {1},{2}x2 = {3}", Environment.NewLine, x1, Environment.NewLine, x2);
                }
            }

            txtKetQua.Text = ketQua;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            DateTime now = DateTime.Now;
            txtKetQua.Text = now.ToString();
        }
    }
}
