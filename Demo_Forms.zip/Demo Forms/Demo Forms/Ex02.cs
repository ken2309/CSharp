﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Demo_Forms
{
    public partial class Ex02 : Form
    {
        public Ex02()
        {
            InitializeComponent();
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtTaiKhoan.Text) || string.IsNullOrEmpty(txtHoTen.Text))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin");
                return;
            }
              
            // Khởi tạo ListViewItem (dòng dữ liệu) -> gán giá trị subitem[0]
            ListViewItem item = new ListViewItem(txtTaiKhoan.Text);

            item.SubItems.Add(txtHoTen.Text);
            item.SubItems.Add(dtpNgaySinh.Value.ToString("dd/MM/yy"));
            item.SubItems.Add(radNam.Checked ? "Nam" : "Nữ");
            item.SubItems.Add(ckbHoatDong.Checked ? "Hoạt động" : "");

            lvThongTin.Items.Add(item);
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            int index = lvThongTin.SelectedIndices[0];

            lvThongTin.Items[index].SubItems[0].Text = txtTaiKhoan.Text;
            lvThongTin.Items[index].SubItems[1].Text = txtHoTen.Text;
            lvThongTin.Items[index].SubItems[2].Text = dtpNgaySinh.Value.ToString("dd/MM/yy");
            lvThongTin.Items[index].SubItems[3].Text = radNam.Checked ? "Nam" : "Nữ";
            lvThongTin.Items[index].SubItems[4].Text = ckbHoatDong.Checked ? "Hoạt động" : "";
        }

        private void lvThongTin_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Kiểm tra người dùng có chọn hay không? 
            if (lvThongTin.SelectedItems.Count > 0)
            {
                ListViewItem item = lvThongTin.SelectedItems[0];

                txtTaiKhoan.Text = item.SubItems[0].Text;
                txtHoTen.Text = item.SubItems[1].Text;
                dtpNgaySinh.Value = DateTime.Parse(item.SubItems[2].Text);
                radNam.Checked = item.SubItems[3].Text == "Nam" ? true : false;
                radNu.Checked = !radNam.Checked; //item.SubItems[3].Text == "Nữ" ? true : false;
                ckbHoatDong.Checked = item.SubItems[4].Text == "Hoạt động" ? true : false;
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtHoTen.Text = string.Empty;
            txtTaiKhoan.Text = string.Empty;
            dtpNgaySinh.Value = DateTime.Now;
            radNam.Checked = true;
            radNu.Checked = false;
            ckbHoatDong.Checked = false;
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            // lỗi <-> bug. fix bugs
            if (lvThongTin.SelectedIndices.Count > 0)
            {
                lvThongTin.Items.RemoveAt(lvThongTin.SelectedIndices[0]);
            }
        }
    }
}
