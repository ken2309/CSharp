﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Demo_Forms
{
    public partial class Ex03 : Form
    {
        public Ex03()
        {
            InitializeComponent();
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            // Lấy thông tin dữ liệu nhập
            string kyNang = txtLapTrinh.Text;

            // Kiểm tra dữ liệu rỗng => thông báo lỗi & thoát
            if (string.IsNullOrEmpty(kyNang))
            {
                MessageBox.Show("Vui lòng nhập dữ liệu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Lấy ra vị trí thông tin (nếu có)
            int index = cklstKyNang.FindString(kyNang);

            // Tồn tại giá trị nhập
            if (index >= 0)
            {
                cklstKyNang.SetItemChecked(index, true);
            }
            else // chưa tồn tại giá trị nhập -> thêm mới & đánh dấu check/tick
            {
                cklstKyNang.Items.Add(kyNang);
                cklstKyNang.SetItemChecked(cklstKyNang.Items.Count - 1, true);
            }

            // Xoá dữ liệu cũ
            txtLapTrinh.Text = string.Empty;
        }

        private void btnXem_Click(object sender, EventArgs e)
        {
            // Kiểm tra ràng buộc dữ liệu nhập
            if (string.IsNullOrEmpty(txtHoTen.Text) || cbbDanToc.SelectedIndex < 0 || cklstKyNang.Items.Count < 0)
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Lấy dữ liệu
            string hoTen = txtHoTen.Text;
            string ngaySinh = dtpNgaySinh.Value.ToString("dd/MM/yy");
            string gioiTinh = radNam.Checked ? "Nam" : "Nữ";
            string danToc = cbbDanToc.SelectedItem.ToString();
            string tinhTrang = radDocThan.Checked ? "Độc thân" : radKetHon.Checked ? "Kết hôn" : "Ly hôn";

            string ngoaiNgu = string.Empty;
            if (ckbAnh.Checked) ngoaiNgu += "Anh ";
            if (ckbPhap.Checked) ngoaiNgu += "Pháp ";
            if (ckbHoa.Checked) ngoaiNgu += "Hoa ";

            lblHoTen.Text = hoTen;
            lblNgaySinh.Text = ngaySinh;
            lblGioiTinh.Text = gioiTinh;
            lblDanToc.Text = danToc;
            lblTinhTrang.Text = tinhTrang;
            lblNgoaiNgu.Text = ngoaiNgu;

            lstKyNang.Items.Clear();

            foreach(var i in cklstKyNang.CheckedItems)
            {
                lstKyNang.Items.Add(i + Environment.NewLine);
            }

            // Mở tab Thông tin sinh viên
            tabControl.SelectedTab = tabThongTin;
        }
    }
}
