﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Demo_Forms
{
    public partial class Test01 : Form
    {
        public Test01()
        {
            InitializeComponent();
        }

        /// Biến toàn cục -> sử dụng chung
        static string strChuoiKetNoi = @"Data Source=QUANGKHAI-MILAP\SQLEXPRESS;Initial Catalog=QLKH;Integrated Security=True";

        // bước 1. Khởi tạo đối tượng kết nối
        SqlConnection connect = new SqlConnection(strChuoiKetNoi);

        private void btnThem_Click(object sender, EventArgs e)
        {
            // viết code xử lý

            // Lấy dữ liệu từ giao diện
            string maKH = txtMaKH.Text;
            string hoTen = txtHoTen.Text;
            string ngaySinh = dtpNgaySinh.Value.ToString("dd/MM/yyyy");
            string gioiTinh = radNam.Checked ? "Nam" : radNu.Checked ? "Nữ" : "Khác";
            string queQuan = cboQueQuan.SelectedIndex >= 0 ? cboQueQuan.SelectedItem.ToString() : string.Empty;
            string diaChi = txtDiaChi.Text;
            
            // Kiểm tra thông tin dữ liệu nhập
            // Không thoả -> Xuất thông báo -> Thoát (return)
            // Thoả -> Thêm khách hàng
            if(string.IsNullOrEmpty(maKH) 
                || string.IsNullOrEmpty(hoTen)
                || string.IsNullOrEmpty(queQuan)
                || string.IsNullOrEmpty(diaChi))
            {
                MessageBox.Show("Vui lòng điền đầy đủ thông tin!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return; // hàm dừng không xử lý lệnh bên dưới
            }

            // 
            // Tạo đối tượng khách hàng mới
            ListViewItem khachHang = new ListViewItem(maKH); // cột thứ 1
            khachHang.SubItems.Add(hoTen); // cột thứ 2
            khachHang.SubItems.Add(gioiTinh); //
            khachHang.SubItems.Add(ngaySinh); //
            khachHang.SubItems.Add(queQuan); // 
            khachHang.SubItems.Add(diaChi); // 

            // Thêm khách hàng mới vào listview
            lvDSKhachHang.Items.Add(khachHang);

            // Thêm dữ liệu vào trong CSDL

            // bước 2. Mở kết nối
            connect.Open();

            string ngaySinhDB = dtpNgaySinh.Value.ToString("yyyy-MM-dd"); 
            int gioiTinhDB = radNam.Checked ? 0 : radNu.Checked ? 1 : 2;

            // bước 3. Xây dựng câu truy vấn
            string strFormat = "INSERT INTO KHACH_HANG(MaKH, HoTen, NgaySinh, GioiTinh, QueQuan, DiaChi) VALUES ('{0}', N'{1}', '{2}', '{3}', N'{4}', N'{5}')";
            string sql = string.Format(strFormat, maKH, hoTen, ngaySinhDB, gioiTinhDB, queQuan, diaChi);

            // bước 4. Xây dựng đối tượng lệnh thực thi (SqlCommand)
            SqlCommand cmd = new SqlCommand(sql, connect);

            // bước 5. thực thi lệnh
            int count = cmd.ExecuteNonQuery();

            // bước 6. Hiển thị kết quả
            if (count > 0)
            {
                MessageBox.Show("Thêm thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Thêm thất bại!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            // bước 7. Đóng kết nối
            connect.Close();

            // Clear dữ liệu trên giao diện
            ClearData();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            // viết code xử lý
            ClearData();

            btnSua.Enabled = false;
            btnXoa.Enabled = false;
            btnThem.Enabled = true;
            txtMaKH.Enabled = true;
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            // viết code xử lý

            // Lấy dữ liệu từ giao diện
            clsKhachHang kh = LayThongTin();

            // Kiểm tra thông tin chỉnh sửa (có đầy đủ dữ liệu)
            // ...

            // Lấy chỉ số dòng được chọn
            int index = lvDSKhachHang.SelectedIndices[0];

            // Cập nhật dữ liệu tại vị trí index trong listview
            lvDSKhachHang.Items[index].SubItems[0].Text = kh.MaKH;
            lvDSKhachHang.Items[index].SubItems[1].Text = kh.HoTen;
            lvDSKhachHang.Items[index].SubItems[2].Text = kh.GioiTinh;
            lvDSKhachHang.Items[index].SubItems[3].Text = kh.NgaySinh;
            lvDSKhachHang.Items[index].SubItems[4].Text = kh.QueQuan;
            lvDSKhachHang.Items[index].SubItems[5].Text = kh.DiaChi;

            // Cập nhật dữ liệu vào trong CSDL

            // bước 2. Mở kết nối
            connect.Open();

            string ngaySinhDB = dtpNgaySinh.Value.ToString("yyyy-MM-dd");
            int gioiTinhDB = radNam.Checked ? 0 : radNu.Checked ? 1 : 2;

            // bước 3. Xây dựng câu truy vấn
            string strFormat = "UPDATE KHACH_HANG SET HoTen = N'{0}', NgaySinh = '{1}', GioiTinh = '{2}', QueQuan = N'{3}', DiaChi = N'{4}' WHERE MaKH = '{5}'";
            string sql = string.Format(strFormat, kh.HoTen, ngaySinhDB, gioiTinhDB, kh.QueQuan, kh.DiaChi, kh.MaKH);

            // bước 4. Xây dựng đối tượng lệnh thực thi (SqlCommand)
            SqlCommand cmd = new SqlCommand(sql, connect);

            // bước 5. thực thi lệnh
            int count = cmd.ExecuteNonQuery();

            // bước 6. Hiển thị kết quả
            if (count > 0)
            {
                MessageBox.Show("Cập nhật thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Cập nhật thất bại!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            // bước 7. Đóng kết nối
            connect.Close();

            // Clear dữ liệu trên giao diện
            ClearData();
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn xoá thông tin!", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (result == DialogResult.Yes)
            {
                // Cập nhật dữ liệu vào trong CSDL

                // Lấy dữ liệu từ giao diện
                string maKH = txtMaKH.Text;

                // bước 2. Mở kết nối
                connect.Open();

                // bước 3. Xây dựng câu truy vấn
                string strFormat = "DELETE FROM KHACH_HANG WHERE MaKH = '{0}'";
                string sql = string.Format(strFormat, maKH);

                // bước 4. Xây dựng đối tượng lệnh thực thi (SqlCommand)
                SqlCommand cmd = new SqlCommand(sql, connect);

                // bước 5. thực thi lệnh
                int count = cmd.ExecuteNonQuery();

                // bước 6. Hiển thị kết quả
                if (count > 0)
                {
                    MessageBox.Show("Xoá thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Xoá thất bại!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

                connect.Close();

                // viết code xử lý
                lvDSKhachHang.Items.Remove(lvDSKhachHang.SelectedItems[0]);

                // Clear dữ liệu trên giao diện
                ClearData();
            }
        }

        private void lvDSKhachHang_SelectedIndexChanged(object sender, EventArgs e)
        {
            // viết code xử lý

            // Kiểm tra nếu người dùng không chọn dòng dữ liệu trong listview
            if (lvDSKhachHang.SelectedItems.Count == 0) return;

            // Nút "Sửa" – "Xoá" được kích hoạt có thể nhấn, nút "Thêm" không thể nhấn.
            btnSua.Enabled = true;
            btnXoa.Enabled = true;
            btnThem.Enabled = false;
            txtMaKH.Enabled = false;

            // Đổ dữ liệu từ dòng được chọn trong listview lên giao diện
            // 1. Lấy thông tin dòng dữ liệu
            ListViewItem khachHang = lvDSKhachHang.SelectedItems[0];

            // 2. Đổ dữ liệu vào giao diện
            txtMaKH.Text = khachHang.SubItems[0].Text;
            txtHoTen.Text = khachHang.SubItems[1].Text;
            
            if (khachHang.SubItems[2].Text == "Nam") radNam.Checked = true;
            if (khachHang.SubItems[2].Text == "Nữ") radNu.Checked = true;
            if (khachHang.SubItems[2].Text == "Khác") radKhac.Checked = true;

            dtpNgaySinh.Value = DateTime.Parse(khachHang.SubItems[3].Text);

            cboQueQuan.SelectedItem = khachHang.SubItems[4].Text;
            txtDiaChi.Text = khachHang.SubItems[5].Text;
        }

        /// <summary>
        /// Hàm xoá dữ liệu trên giao diện
        /// </summary>
        private void ClearData()
        {
            // Clear dữ liệu trên giao diện
            txtMaKH.Text = string.Empty;
            txtHoTen.Text = string.Empty;
            radNam.Checked = true;
            dtpNgaySinh.Value = DateTime.Now;
            cboQueQuan.SelectedIndex = 0;
            txtDiaChi.Text = string.Empty;
        }

        private clsKhachHang LayThongTin()
        {
            clsKhachHang kh = new clsKhachHang();

            // Lấy dữ liệu từ giao diện
            kh.MaKH = txtMaKH.Text;
            kh.HoTen = txtHoTen.Text;
            kh.NgaySinh = dtpNgaySinh.Value.ToString("dd/MM/yyyy");
            kh.GioiTinh = radNam.Checked ? "Nam" : radNu.Checked ? "Nữ" : "Khác";
            kh.QueQuan = cboQueQuan.SelectedIndex >= 0 ? cboQueQuan.SelectedItem.ToString() : string.Empty;
            kh.DiaChi = txtDiaChi.Text;

            return kh;
        }
    }
}
