﻿namespace Demo_Forms
{
    partial class Ex03
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabNhap = new System.Windows.Forms.TabPage();
            this.radNam = new System.Windows.Forms.RadioButton();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtHoTen = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabThongTin = new System.Windows.Forms.TabPage();
            this.radNu = new System.Windows.Forms.RadioButton();
            this.cbbDanToc = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.ckbAnh = new System.Windows.Forms.CheckBox();
            this.ckbPhap = new System.Windows.Forms.CheckBox();
            this.ckbHoa = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtLapTrinh = new System.Windows.Forms.TextBox();
            this.btnThem = new System.Windows.Forms.Button();
            this.cklstKyNang = new System.Windows.Forms.CheckedListBox();
            this.btnXem = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.lstKyNang = new System.Windows.Forms.ListBox();
            this.lblHoTen = new System.Windows.Forms.Label();
            this.lblNgaySinh = new System.Windows.Forms.Label();
            this.lblGioiTinh = new System.Windows.Forms.Label();
            this.lblDanToc = new System.Windows.Forms.Label();
            this.lblTinhTrang = new System.Windows.Forms.Label();
            this.lblNgoaiNgu = new System.Windows.Forms.Label();
            this.dtpNgaySinh = new System.Windows.Forms.DateTimePicker();
            this.radDocThan = new System.Windows.Forms.RadioButton();
            this.radKetHon = new System.Windows.Forms.RadioButton();
            this.radLyHon = new System.Windows.Forms.RadioButton();
            this.tabControl.SuspendLayout();
            this.tabNhap.SuspendLayout();
            this.tabThongTin.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tabNhap);
            this.tabControl.Controls.Add(this.tabThongTin);
            this.tabControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl.Location = new System.Drawing.Point(0, 0);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(452, 520);
            this.tabControl.TabIndex = 0;
            // 
            // tabNhap
            // 
            this.tabNhap.Controls.Add(this.dtpNgaySinh);
            this.tabNhap.Controls.Add(this.btnXem);
            this.tabNhap.Controls.Add(this.groupBox2);
            this.tabNhap.Controls.Add(this.groupBox1);
            this.tabNhap.Controls.Add(this.cbbDanToc);
            this.tabNhap.Controls.Add(this.ckbHoa);
            this.tabNhap.Controls.Add(this.ckbPhap);
            this.tabNhap.Controls.Add(this.ckbAnh);
            this.tabNhap.Controls.Add(this.radNu);
            this.tabNhap.Controls.Add(this.radNam);
            this.tabNhap.Controls.Add(this.label4);
            this.tabNhap.Controls.Add(this.label5);
            this.tabNhap.Controls.Add(this.label3);
            this.tabNhap.Controls.Add(this.label2);
            this.tabNhap.Controls.Add(this.txtHoTen);
            this.tabNhap.Controls.Add(this.label1);
            this.tabNhap.Location = new System.Drawing.Point(4, 29);
            this.tabNhap.Name = "tabNhap";
            this.tabNhap.Padding = new System.Windows.Forms.Padding(3);
            this.tabNhap.Size = new System.Drawing.Size(444, 487);
            this.tabNhap.TabIndex = 0;
            this.tabNhap.Text = "Nhập thông tin cá nhân";
            this.tabNhap.UseVisualStyleBackColor = true;
            // 
            // radNam
            // 
            this.radNam.AutoSize = true;
            this.radNam.Checked = true;
            this.radNam.Location = new System.Drawing.Point(241, 86);
            this.radNam.Name = "radNam";
            this.radNam.Size = new System.Drawing.Size(67, 24);
            this.radNam.TabIndex = 2;
            this.radNam.TabStop = true;
            this.radNam.Text = "Nam";
            this.radNam.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(44, 118);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 20);
            this.label4.TabIndex = 0;
            this.label4.Text = "Dân tộc";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(44, 86);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 20);
            this.label3.TabIndex = 0;
            this.label3.Text = "Giới tính";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(44, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 20);
            this.label2.TabIndex = 0;
            this.label2.Text = "Ngày sinh";
            // 
            // txtHoTen
            // 
            this.txtHoTen.Location = new System.Drawing.Point(126, 19);
            this.txtHoTen.Name = "txtHoTen";
            this.txtHoTen.Size = new System.Drawing.Size(262, 26);
            this.txtHoTen.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(43, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Họ và tên";
            // 
            // tabThongTin
            // 
            this.tabThongTin.Controls.Add(this.lblNgoaiNgu);
            this.tabThongTin.Controls.Add(this.lblTinhTrang);
            this.tabThongTin.Controls.Add(this.lblDanToc);
            this.tabThongTin.Controls.Add(this.lblGioiTinh);
            this.tabThongTin.Controls.Add(this.lblNgaySinh);
            this.tabThongTin.Controls.Add(this.lblHoTen);
            this.tabThongTin.Controls.Add(this.groupBox3);
            this.tabThongTin.Controls.Add(this.label11);
            this.tabThongTin.Controls.Add(this.label10);
            this.tabThongTin.Controls.Add(this.label9);
            this.tabThongTin.Controls.Add(this.label8);
            this.tabThongTin.Controls.Add(this.label7);
            this.tabThongTin.Controls.Add(this.label6);
            this.tabThongTin.Location = new System.Drawing.Point(4, 29);
            this.tabThongTin.Name = "tabThongTin";
            this.tabThongTin.Padding = new System.Windows.Forms.Padding(3);
            this.tabThongTin.Size = new System.Drawing.Size(444, 487);
            this.tabThongTin.TabIndex = 1;
            this.tabThongTin.Text = "Thông tin cá nhân";
            this.tabThongTin.UseVisualStyleBackColor = true;
            // 
            // radNu
            // 
            this.radNu.AutoSize = true;
            this.radNu.Location = new System.Drawing.Point(334, 86);
            this.radNu.Name = "radNu";
            this.radNu.Size = new System.Drawing.Size(54, 24);
            this.radNu.TabIndex = 2;
            this.radNu.Text = "Nữ";
            this.radNu.UseVisualStyleBackColor = true;
            // 
            // cbbDanToc
            // 
            this.cbbDanToc.FormattingEnabled = true;
            this.cbbDanToc.Items.AddRange(new object[] {
            "Kinh",
            "Hoa",
            "Mường",
            "Ê Đê",
            "Khơme",
            "Chăm"});
            this.cbbDanToc.Location = new System.Drawing.Point(126, 115);
            this.cbbDanToc.Name = "cbbDanToc";
            this.cbbDanToc.Size = new System.Drawing.Size(262, 28);
            this.cbbDanToc.TabIndex = 3;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radLyHon);
            this.groupBox1.Controls.Add(this.radKetHon);
            this.groupBox1.Controls.Add(this.radDocThan);
            this.groupBox1.Location = new System.Drawing.Point(48, 149);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(340, 75);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Tình trạng hôn nhân";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(44, 231);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(81, 20);
            this.label5.TabIndex = 0;
            this.label5.Text = "Ngoại ngữ";
            // 
            // ckbAnh
            // 
            this.ckbAnh.AutoSize = true;
            this.ckbAnh.Location = new System.Drawing.Point(148, 230);
            this.ckbAnh.Name = "ckbAnh";
            this.ckbAnh.Size = new System.Drawing.Size(64, 24);
            this.ckbAnh.TabIndex = 0;
            this.ckbAnh.Text = "Anh";
            this.ckbAnh.UseVisualStyleBackColor = true;
            // 
            // ckbPhap
            // 
            this.ckbPhap.AutoSize = true;
            this.ckbPhap.Location = new System.Drawing.Point(218, 230);
            this.ckbPhap.Name = "ckbPhap";
            this.ckbPhap.Size = new System.Drawing.Size(72, 24);
            this.ckbPhap.TabIndex = 0;
            this.ckbPhap.Text = "Pháp";
            this.ckbPhap.UseVisualStyleBackColor = true;
            // 
            // ckbHoa
            // 
            this.ckbHoa.AutoSize = true;
            this.ckbHoa.Location = new System.Drawing.Point(296, 230);
            this.ckbHoa.Name = "ckbHoa";
            this.ckbHoa.Size = new System.Drawing.Size(65, 24);
            this.ckbHoa.TabIndex = 0;
            this.ckbHoa.Text = "Hoa";
            this.ckbHoa.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cklstKyNang);
            this.groupBox2.Controls.Add(this.btnThem);
            this.groupBox2.Controls.Add(this.txtLapTrinh);
            this.groupBox2.Location = new System.Drawing.Point(48, 261);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(341, 170);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Kỹ năng lập trình";
            // 
            // txtLapTrinh
            // 
            this.txtLapTrinh.Location = new System.Drawing.Point(6, 32);
            this.txtLapTrinh.Name = "txtLapTrinh";
            this.txtLapTrinh.Size = new System.Drawing.Size(237, 26);
            this.txtLapTrinh.TabIndex = 0;
            // 
            // btnThem
            // 
            this.btnThem.Location = new System.Drawing.Point(249, 25);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(89, 40);
            this.btnThem.TabIndex = 1;
            this.btnThem.Text = "Thêm";
            this.btnThem.UseVisualStyleBackColor = true;
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click);
            // 
            // cklstKyNang
            // 
            this.cklstKyNang.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.cklstKyNang.FormattingEnabled = true;
            this.cklstKyNang.Items.AddRange(new object[] {
            "C/C++",
            "C#"});
            this.cklstKyNang.Location = new System.Drawing.Point(3, 71);
            this.cklstKyNang.Name = "cklstKyNang";
            this.cklstKyNang.Size = new System.Drawing.Size(335, 96);
            this.cklstKyNang.TabIndex = 2;
            // 
            // btnXem
            // 
            this.btnXem.Location = new System.Drawing.Point(300, 437);
            this.btnXem.Name = "btnXem";
            this.btnXem.Size = new System.Drawing.Size(89, 40);
            this.btnXem.TabIndex = 6;
            this.btnXem.Text = "Xem";
            this.btnXem.UseVisualStyleBackColor = true;
            this.btnXem.Click += new System.EventHandler(this.btnXem_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(39, 20);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(85, 20);
            this.label6.TabIndex = 0;
            this.label6.Text = "Họ và tên: ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(39, 56);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(82, 20);
            this.label7.TabIndex = 0;
            this.label7.Text = "Ngày sinh:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(39, 94);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(71, 20);
            this.label8.TabIndex = 0;
            this.label8.Text = "Giới tính:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(39, 131);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(69, 20);
            this.label9.TabIndex = 0;
            this.label9.Text = "Dân tộc:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(39, 169);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(159, 20);
            this.label10.TabIndex = 0;
            this.label10.Text = "Tình trạng hôn nhân: ";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(39, 204);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(85, 20);
            this.label11.TabIndex = 0;
            this.label11.Text = "Ngoại ngữ:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.lstKyNang);
            this.groupBox3.Location = new System.Drawing.Point(43, 242);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(360, 211);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Kỹ năng";
            // 
            // lstKyNang
            // 
            this.lstKyNang.FormattingEnabled = true;
            this.lstKyNang.ItemHeight = 20;
            this.lstKyNang.Location = new System.Drawing.Point(6, 25);
            this.lstKyNang.Name = "lstKyNang";
            this.lstKyNang.Size = new System.Drawing.Size(348, 164);
            this.lstKyNang.TabIndex = 0;
            // 
            // lblHoTen
            // 
            this.lblHoTen.AutoSize = true;
            this.lblHoTen.ForeColor = System.Drawing.Color.MediumBlue;
            this.lblHoTen.Location = new System.Drawing.Point(202, 20);
            this.lblHoTen.Name = "lblHoTen";
            this.lblHoTen.Size = new System.Drawing.Size(0, 20);
            this.lblHoTen.TabIndex = 2;
            // 
            // lblNgaySinh
            // 
            this.lblNgaySinh.AutoSize = true;
            this.lblNgaySinh.ForeColor = System.Drawing.Color.MediumBlue;
            this.lblNgaySinh.Location = new System.Drawing.Point(202, 56);
            this.lblNgaySinh.Name = "lblNgaySinh";
            this.lblNgaySinh.Size = new System.Drawing.Size(0, 20);
            this.lblNgaySinh.TabIndex = 2;
            // 
            // lblGioiTinh
            // 
            this.lblGioiTinh.AutoSize = true;
            this.lblGioiTinh.ForeColor = System.Drawing.Color.MediumBlue;
            this.lblGioiTinh.Location = new System.Drawing.Point(202, 94);
            this.lblGioiTinh.Name = "lblGioiTinh";
            this.lblGioiTinh.Size = new System.Drawing.Size(0, 20);
            this.lblGioiTinh.TabIndex = 2;
            // 
            // lblDanToc
            // 
            this.lblDanToc.AutoSize = true;
            this.lblDanToc.ForeColor = System.Drawing.Color.MediumBlue;
            this.lblDanToc.Location = new System.Drawing.Point(202, 131);
            this.lblDanToc.Name = "lblDanToc";
            this.lblDanToc.Size = new System.Drawing.Size(0, 20);
            this.lblDanToc.TabIndex = 2;
            // 
            // lblTinhTrang
            // 
            this.lblTinhTrang.AutoSize = true;
            this.lblTinhTrang.ForeColor = System.Drawing.Color.MediumBlue;
            this.lblTinhTrang.Location = new System.Drawing.Point(202, 169);
            this.lblTinhTrang.Name = "lblTinhTrang";
            this.lblTinhTrang.Size = new System.Drawing.Size(0, 20);
            this.lblTinhTrang.TabIndex = 2;
            // 
            // lblNgoaiNgu
            // 
            this.lblNgoaiNgu.AutoSize = true;
            this.lblNgoaiNgu.ForeColor = System.Drawing.Color.MediumBlue;
            this.lblNgoaiNgu.Location = new System.Drawing.Point(202, 204);
            this.lblNgoaiNgu.Name = "lblNgoaiNgu";
            this.lblNgoaiNgu.Size = new System.Drawing.Size(0, 20);
            this.lblNgoaiNgu.TabIndex = 2;
            // 
            // dtpNgaySinh
            // 
            this.dtpNgaySinh.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpNgaySinh.Location = new System.Drawing.Point(126, 49);
            this.dtpNgaySinh.Name = "dtpNgaySinh";
            this.dtpNgaySinh.Size = new System.Drawing.Size(262, 26);
            this.dtpNgaySinh.TabIndex = 7;
            // 
            // radDocThan
            // 
            this.radDocThan.AutoSize = true;
            this.radDocThan.Checked = true;
            this.radDocThan.Location = new System.Drawing.Point(16, 35);
            this.radDocThan.Name = "radDocThan";
            this.radDocThan.Size = new System.Drawing.Size(99, 24);
            this.radDocThan.TabIndex = 0;
            this.radDocThan.TabStop = true;
            this.radDocThan.Text = "Độc thân";
            this.radDocThan.UseVisualStyleBackColor = true;
            // 
            // radKetHon
            // 
            this.radKetHon.AutoSize = true;
            this.radKetHon.Location = new System.Drawing.Point(121, 35);
            this.radKetHon.Name = "radKetHon";
            this.radKetHon.Size = new System.Drawing.Size(89, 24);
            this.radKetHon.TabIndex = 0;
            this.radKetHon.Text = "Kết hôn";
            this.radKetHon.UseVisualStyleBackColor = true;
            // 
            // radLyHon
            // 
            this.radLyHon.AutoSize = true;
            this.radLyHon.Location = new System.Drawing.Point(216, 35);
            this.radLyHon.Name = "radLyHon";
            this.radLyHon.Size = new System.Drawing.Size(81, 24);
            this.radLyHon.TabIndex = 0;
            this.radLyHon.Text = "Ly hôn";
            this.radLyHon.UseVisualStyleBackColor = true;
            // 
            // Ex03
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(452, 520);
            this.Controls.Add(this.tabControl);
            this.Name = "Ex03";
            this.Text = "Ex03";
            this.tabControl.ResumeLayout(false);
            this.tabNhap.ResumeLayout(false);
            this.tabNhap.PerformLayout();
            this.tabThongTin.ResumeLayout(false);
            this.tabThongTin.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabNhap;
        private System.Windows.Forms.TabPage tabThongTin;
        private System.Windows.Forms.RadioButton radNam;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtHoTen;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton radNu;
        private System.Windows.Forms.Button btnXem;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckedListBox cklstKyNang;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.TextBox txtLapTrinh;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cbbDanToc;
        private System.Windows.Forms.CheckBox ckbHoa;
        private System.Windows.Forms.CheckBox ckbPhap;
        private System.Windows.Forms.CheckBox ckbAnh;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ListBox lstKyNang;
        private System.Windows.Forms.Label lblNgoaiNgu;
        private System.Windows.Forms.Label lblTinhTrang;
        private System.Windows.Forms.Label lblDanToc;
        private System.Windows.Forms.Label lblGioiTinh;
        private System.Windows.Forms.Label lblNgaySinh;
        private System.Windows.Forms.Label lblHoTen;
        private System.Windows.Forms.DateTimePicker dtpNgaySinh;
        private System.Windows.Forms.RadioButton radLyHon;
        private System.Windows.Forms.RadioButton radKetHon;
        private System.Windows.Forms.RadioButton radDocThan;
    }
}