﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Demo_Forms
{
    public partial class Ex07 : Form
    {
        public Ex07()
        {
            InitializeComponent();

            // Cập nhật dữ liệu thể hiện ListView
            UpdateData();
        }

        // Đường dẫn thư mục chứa file dữ liệu và hình
        string folderPath = @"D:\Google Drive (khaitq.10@grad.uit.edu.vn)\02. Thỉnh Giảng\04. Aptech-SaiGon\Programming in C#\Demo Forms\Demo Forms\TRASUA";

        // Danh sách trà sữa
        List<clsTraSua> lstTraSua = new List<clsTraSua>();

        /// <summary>
        /// Cập nhật dữ liệu từ tập tin nguồn ra ListView
        /// </summary>
        private void UpdateData()
        {
            ReadFile();
            LoadImageList();
            LoadDSTraSua();
        }

        /// <summary>
        /// Đọc thư mục ảnh gán vào ImageList
        /// </summary>
        private void LoadImageList()
        {
            // Xoá danh sách hình ảnh trong ImageList
            imgListTraSuaLarge.Images.Clear();
            imgListTraSuaSmall.Images.Clear();

            // Lấy thông tin thư mục
            DirectoryInfo dir = new DirectoryInfo(folderPath);

            // Lấy tất cả các tập tin có phần mở rộng là jpg trong thư mục bên trên
            FileInfo[] listFile = dir.GetFiles("*.jpg");

            // Duyệt từng tập tin... 
            foreach (FileInfo fi in listFile)
            {
                // ... để thêm hình vào từ file trong thư mục
                // với tên file làm imageKey để phân biệt

                byte[] bytes = System.IO.File.ReadAllBytes(fi.FullName);
                System.IO.MemoryStream ms = new System.IO.MemoryStream(bytes);

                // ... hình lớn

                imgListTraSuaLarge.Images.Add(fi.Name, Image.FromStream(ms));

                // ... hình nhỏ
                imgListTraSuaSmall.Images.Add(fi.Name, Image.FromStream(ms));
            }
        }

        /// <summary>
        /// Đọc tập tin lấy giá trị mã trà, tên trà, đơn giá đưa vào mảng
        /// </summary>
        private void ReadFile()
        {
            // Xoá danh sách thông tin trước khi lấy lại dữ liệu mới
            lstTraSua.Clear();

            string line; // Lưu dòng dữ dữ liệu đang đọc từ file
            string[] splitter; // Mảng cắt thông tin từ dòng dữ liệu phân cách nhau bằng dấu ','
            StreamReader srd = new StreamReader(folderPath + "/DSTraSua.txt");

            // Đọc tập tin đến khi nào dòng bằng null (dòng rỗng)
            while ((line = srd.ReadLine()) != null)
            {
                // Xử lý dòng đang đọc từ tập tin
                // cắt dòng theo dấu ',' thành các đoạn
                // mà mỗi đoạn là một phần tử trong mảng chuỗi
                splitter = line.Split(',');

                // Tạo đối tượng trà sữa, lấy thông tin
                clsTraSua traSua = new clsTraSua();

                traSua.MaTra = splitter[0];
                traSua.TenTra = splitter[1];
                traSua.DonGia = long.Parse(splitter[2]);

                // Thêm đối tượng vào danh sách trà sữa
                lstTraSua.Add(traSua);
            }

            srd.Close();
            srd.Dispose();
            System.GC.Collect();
        }

        /// <summary>
        /// Ghi dữ liệu ra tập tin nguồn
        /// </summary>
        private void WriteFile()
        {
            using (StreamWriter sw = new StreamWriter(folderPath + "/DSTraSua.txt", false))
            {
                for (int i = 0; i < lstTraSua.Count; i++)
                {
                    // Định dạng dữ liệu thành từng dòng
                    string line = string.Format("{0},{1},{2}", lstTraSua[i].MaTra, lstTraSua[i].TenTra, lstTraSua[i].DonGia);
                    sw.WriteLine(line);
                }

                sw.Close();
                sw.Dispose();
                System.GC.Collect();
            }
        }

        /// <summary>
        /// Hiển thị danh sách trà sữa lên ListView
        /// </summary>
        private void LoadDSTraSua()
        {
            // Làm mới ListView xoá hết các đối tượng cũ
            lvDSTraSua.Items.Clear();

            // Duyệt qua thông tin từng đối tượng trà sữa (mã trà, tên trà, đơn giá)
            for (int i = 0; i < lstTraSua.Count; i++)
            {
                // Mối Item có thêm hình ảnh từ ImageList, truy xuất bằng imagekey (tên hình)
                ListViewItem lvi = new ListViewItem(lstTraSua[i].MaTra, lstTraSua[i].MaTra + ".jpg");

                // Thêm thông tin vào đối tượng con
                lvi.SubItems.Add(lstTraSua[i].TenTra);
                lvi.SubItems.Add(lstTraSua[i].DonGia.ToString());

                // Thêm đối tượng vào ListView
                lvDSTraSua.Items.Add(lvi);
            }
        }

        /// <summary>
        /// Thực thi khi trạng thái các tuỳ chọn View Style thay đổi
        /// </summary>
        private void radOption_CheckedChanged(object sender, EventArgs e)
        {
            lvDSTraSua.View = radLargeIcon.Checked ? View.LargeIcon : radSmallIcon.Checked ? View.SmallIcon : radDetails.Checked ? View.Details : radList.Checked ? View.List : View.Tile;
        }

        private void lvDSTraSua_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Xứ lý button
            btnXoa.Enabled = true;
            btnSua.Enabled = true;
            btnLuu.Enabled = false;
            btnThem.Enabled = true;

            // Xử lý đối tượng thông tin
            txtMaTS.ReadOnly = true;
            txtTenTS.ReadOnly = true;
            txtDonGia.ReadOnly = true;
            pbHinh.Enabled = false;

            // Chỉ xứ lý khi người dùng chọn đối tượng trong ListView
            // tức số lượng được chọn > 0
            if (lvDSTraSua.SelectedItems.Count > 0)
            {
                // Lấy đối tượng được chọn đầu tiên hiển thị thông tin
                txtMaTS.Text = lvDSTraSua.SelectedItems[0].Text;
                txtTenTS.Text = lvDSTraSua.SelectedItems[0].SubItems[1].Text;
                txtDonGia.Text = lvDSTraSua.SelectedItems[0].SubItems[2].Text;

                // Kiểm tra có hình ảnh trong thư mục hay không? 
                if (File.Exists(folderPath + "/" + txtMaTS.Text + ".jpg"))
                {
                    // chuyển hình thành dữ liệu byte
                    byte[] byteHA = File.ReadAllBytes(folderPath + "/" + txtMaTS.Text + ".jpg");
                    // chuyển dữ liệu thành đối tượng MemoryStream cho việc chuyển dữ liệu
                    MemoryStream mos = new MemoryStream(byteHA);
                    // Tạo đối tượng Image từ MemoryStream
                    pbHinh.Image = Image.FromStream(mos);

                    mos.Close();
                    mos.Dispose();
                    System.GC.Collect();
                }
                else
                {
                    pbHinh.Image = null;
                }
            }
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            // Xứ lý button
            btnXoa.Enabled = false;
            btnSua.Enabled = false;
            btnLuu.Enabled = true;
            btnThem.Enabled = true;

            // Xử lý đối tượng thông tin
            txtMaTS.ReadOnly = true;
            txtTenTS.ReadOnly = false;
            txtDonGia.ReadOnly = false;
            pbHinh.Enabled = true;

            // Phát sinh mã trà sữa
            int index = Convert.ToInt32(lstTraSua.Max().MaTra.Substring(2));

            txtMaTS.Text = string.Format("TS{0}", (index + 1).ToString("000"));

            // Xoá các trường dữ liệu
            pbHinh.Image = null;
            txtTenTS.Text = string.Empty;
            txtDonGia.Text = string.Empty;
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            // Xứ lý button
            btnXoa.Enabled = false;
            btnSua.Enabled = false;
            btnLuu.Enabled = true;
            btnThem.Enabled = true;

            // Xử lý đối tượng thông tin
            txtMaTS.ReadOnly = false;
            txtTenTS.ReadOnly = false;
            txtDonGia.ReadOnly = false;
            pbHinh.Enabled = true;

            // Xóa đối tượng trà sữa
            lstTraSua.Remove(lstTraSua.SingleOrDefault(u => u.MaTra == txtMaTS.Text));

            // Xoá hình ảnh
            File.Delete(folderPath + "/" + txtMaTS.Text + ".jpg");

            // Xoá hết các trường nhập thông tin
            pbHinh.Image = null;
            txtMaTS.Text = string.Empty;
            txtTenTS.Text = string.Empty;
            txtDonGia.Text = string.Empty;

            // Ghi dữ liệu ra tập tin
            WriteFile();

            // Cập nhật dữ liệu trong ListView
            UpdateData();
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            // Xứ lý button
            btnXoa.Enabled = true;
            btnSua.Enabled = true;
            btnLuu.Enabled = true;
            btnThem.Enabled = true;

            // Xử lý đối tượng thông tin
            txtMaTS.ReadOnly = true;
            txtTenTS.ReadOnly = false;
            txtDonGia.ReadOnly = false;
            pbHinh.Enabled = true;

        }

        /// <summary>
        /// Chuyển đối tượng Image sang mảng byte cho việc lưu hình ảnh
        /// </summary>
        public byte[] ConvertImageToByteArray(Image imageToConvert)
        {
            using (var ms = new MemoryStream())
            {
                // Chuyển image sang kiểu bitmap
                Bitmap bmp = new Bitmap(imageToConvert);

                // Lưu bitmap thành MemoryStream cho việc lưu trữ ảnh
                bmp.Save(ms, ImageFormat.Jpeg);

                return ms.ToArray();
            }
        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            // Xử lý button khi thêm đối tượng
            btnXoa.Enabled = false;
            btnSua.Enabled = true;
            btnLuu.Enabled = true;
            btnThem.Enabled = true;

            // Xử lý đối tượng thông tin khi thêm/sửa đối tượng
            txtMaTS.ReadOnly = false;
            txtTenTS.ReadOnly = false;
            txtDonGia.ReadOnly = false;
            pbHinh.Enabled = false;

            // linq 
            // lstTraSua -> List (Mảng) -> Table trong SQL Server
            // SELECT * FROM lstTraSua
            // SELECT * FORM lstTraSua WHERE MaTra = 'TS001'
            lstTraSua.Where(u => u.MaTra == "TS001");

            // Lưu trong trường hợp thêm mới đối tượng trà sữa
            if (lstTraSua.SingleOrDefault(u => u.MaTra == txtMaTS.Text) == null)
            {
                //  Thêm đối tượng mới vào các danh sách thông tin
                clsTraSua traSua = new clsTraSua();

                traSua.MaTra = txtMaTS.Text;
                traSua.TenTra = txtTenTS.Text;
                traSua.DonGia = long.Parse(txtDonGia.Text);

                // Thêm trà sữa vào danh sách
                lstTraSua.Add(traSua);

                // Lưu tập tin hình về đối tượng
                using (MemoryStream memory = new MemoryStream())
                {
                    using (FileStream fs = new FileStream(folderPath + "/" + txtMaTS.Text + ".jpg",
                        FileMode.Create, FileAccess.ReadWrite))
                    {
                        byte[] bytes = ConvertImageToByteArray(pbHinh.Image);
                        fs.Write(bytes, 0, bytes.Length);
                    }
                }

                // Xoá hết các trường nhập thông tin
                pbHinh.Image = null;
                txtMaTS.Text = string.Empty;
                txtTenTS.Text = string.Empty;
                txtDonGia.Text = string.Empty;
            }
            else // Lưu trong trường hợp chỉnh sửa
            {
                // Lấy chỉ số vị trí cập nhật dữ liệu trong các danh sách
                int index = lstTraSua.IndexOf(lstTraSua.SingleOrDefault(u => u.MaTra == txtMaTS.Text));

                // Cập nhật giá trị 
                lstTraSua[index].TenTra = txtTenTS.Text;
                lstTraSua[index].DonGia = Convert.ToInt64(txtDonGia.Text);

                // Lưu tập tin hình về đối tượng
                using (MemoryStream memory = new MemoryStream())
                {
                    using (FileStream fs = new FileStream(folderPath + "/" + txtMaTS.Text + ".jpg",
                        FileMode.Create, FileAccess.ReadWrite))
                    {
                        byte[] bytes = ConvertImageToByteArray(pbHinh.Image);
                        fs.Write(bytes, 0, bytes.Length);

                        fs.Close();
                        fs.Dispose();
                        System.GC.Collect();
                    }

                    memory.Close();
                    memory.Dispose();
                    System.GC.Collect();
                }

                // Khoá hết các trường nhập thông tin
                txtMaTS.ReadOnly = true;
                txtTenTS.ReadOnly = true;
                txtDonGia.ReadOnly = true;
            }


            // Ghi dữ liệu ra tập tin
            WriteFile();

            // Cập nhật dữ liệu cho GridView
            UpdateData();
        }

        private void pbHinh_Click(object sender, EventArgs e)
        {
            // Tạo đối tượng đọc hình ảnh
            Stream myStream = null;

            // Mặc định OpenFileDialog mở ổ đĩa C:\
            ofdFile.InitialDirectory = "C:\\";
            // Lọc những loại tập tin có thể mở được (trong bài này là hình ảnh)
            ofdFile.Filter = "Image files (*.jpg, *.jpeg, *.jpe, *.jfif, *.png) | *.jpg; *.jpeg; *.jpe; *.jfif; *.png";
            ofdFile.FilterIndex = 2;
            ofdFile.RestoreDirectory = true;

            // Hiển thị hộp thoại
            if (ofdFile.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    // Tập tin tồn tại
                    if ((myStream = ofdFile.OpenFile()) != null)
                    {
                        // Đọc tập tin và hiển thị PictureBox
                        using (myStream)
                        {
                            // Insert code to read the stream here.
                            pbHinh.Image = Image.FromStream(myStream);
                        }
                    }
                }
                catch (Exception ex) // Thông báo lỗi trong trường hợp đọc hình ảnh
                {
                    MessageBox.Show("Error: Could not read file from disk. Original error: " + ex.Message);
                }

                myStream.Close();
                myStream.Dispose();
                System.GC.Collect();
            }
        }

        
    }
}
